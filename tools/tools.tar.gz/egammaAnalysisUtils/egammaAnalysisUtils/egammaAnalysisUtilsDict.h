#ifndef EGAMMAANALYSISUTILS_EGAMMAANALYSISUTILSDICT_H
#define EGAMMAANALYSISUTILS_EGAMMAANALYSISUTILSDICT_H

#include "egammaAnalysisUtils/egammaSFclass.h"
#include "egammaAnalysisUtils/EnergyRescaler.h"
#include "egammaAnalysisUtils/checkOQ.h"

#endif
