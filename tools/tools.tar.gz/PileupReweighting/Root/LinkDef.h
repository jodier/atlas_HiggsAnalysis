#include <vector>
#include <string>
#include "TString.h"
#include <PileupReweighting/TPileupReweighting.h>

#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ namespace Root ;

#pragma link C++ class Root::TPileupReweighting+ ; 

#endif
